# Analysing-Hotel-Data
### (The dashboard is included here for reference)
## Note: In the original dashboard it is possible to select the date range, hotel and country for customising the visualizations accordingly

![Dashboard Page 1](https://github.com/shivtosh/Analysing-Hotel-Data/blob/main/Dashboard1024_1.jpg?raw=true)

